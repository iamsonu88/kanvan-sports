<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js"></script>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
<?php


global $wpdb;
if(null!==$_POST['orderId'] && $_POST['txStatus']=='SUCCESS') {
	$email_id=base64_decode($_GET['email_id']);
	$user_data=get_user_by_email($email_id);
	$user_id=$user_data->data->ID;
	$user_activation_key=$user_data->data->user_activation_key;
	foreach($_POST as $key=>$data){
		add_user_meta( $user_id, $key, $data);
	}
	update_user_meta( $user_id, 'payment_status', 'success' );
	//session_destroy();

	$to = $email_id;
	$subject = "Verification Mail from Super Markeet";
	$txt = "Hello ".$email_id.". Thanks for registering with us. Please check your email to activate your account!";
	$emailTxt = "Hello ".$email_id.". <br/><br/> Thanks for registering with us. <br/>Please click on below link for activate account!<br/><br/>".get_permalink()."?email_id=".$email_id."&activation_key=".$user_activation_key;
	$user_meta_data=get_user_meta( $user_id );
	$phone_number=$user_meta_data['phone_number'][0];
	send_success_sms($phone_number, $txt);
	$message='<section class="full-page container" style="padding-top: 1rem; width: 100%; clear: both;">
		<div class="heading-one" style="padding: 18px 30px 98px 30px; background-color: #fdb143; color: #fff; font-size: 24px; clear: both;">
			<div style="width: 22%; float: left;"><a href="https://www.supermarkeet.com/" title="Super Markeet"><img style="width: 80%;" src="https://www.supermarkeet.com/wp-content/uploads/2020/08/cropped-supermarkeet.png" alt="Super Markeet Logo" /></a> </div>
			<h1 style="margin-top: 0px; float: left;  width: 70%;">Welcome to Super Markeet</h1>
		</div>
		<div style="clear: both; margin-left: 2%; margin-bottom: 4%; font-size: 18px;">
			<span style="font-size: 30px;">Your Payment Invoice</span>
    		<table style="text-align: left; color: black; width: 60%;">
				<tr>
					<th style="font-weight: 100; width: 44%;">Registration Charges</th>
					<td style="width: 10%;"> : </td>
					<td style="font-weight: 600; width: 40%;"> 199 INR</td>
				</tr>
				<tr>
					<th style="font-weight: 100; width: 44%;">GST Charges:</th>
					<td style="width: 10%;"> : </td>
					<td style="font-weight: 600;  width: 40%;"> 35.82 INR</td>
				</tr>
				<tr>
					<td colspan="3" style="border-top: 1px solid black;"></td>
				</tr>
				<tr>
					<th style="font-weight: 100; width: 44%;">Total Cost:</th>
					<td style="width: 10%;"> : </td>
					<td style="font-weight: 600;  width: 40%;"> 234.82 INR  : (Round) - 235 INR</td>
				</tr>
			</table>
		</div>
		<div class="sub-title" style="padding: 16px; border: 1px solid #ddd;">'.$emailTxt.'</div>
	</section>';
	$from = 'support@supermarkeet.com';
	$headers  = 'MIME-Version: 1.0' . "\r\n";
	$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
 	// Create email headers
	$headers .= 'From: '.$from."\r\n". 'Reply-To: '.$from."\r\n" . 'X-Mailer: PHP/' . phpversion();
	if(mail($to,$subject,$message,$headers)) {
		echo 'Your mail has been sent successfully.';
	} else {
		echo 'Unable to send email. Please try again.';
	}


	$success_msg="You have successfully pay for Shop manager Account. Please verify the account using email!";
	echo "<script>swal('Success','".$success_msg."','success')</script>";
	echo "<script>setTimeout(function(){ window.location.href='".home_url()."'; }, 5000)</script>";
}
if(null!==$_POST['orderId'] && $_POST['txStatus']=='CANCELLED') {
	$email_id=base64_decode($_GET['email_id']);
	$user_data=get_user_by_email($email_id);
	$user_id=$user_data->data->ID;
	$user_activation_key=$user_data->data->user_activation_key;
	foreach($_POST as $key=>$data){
		add_user_meta( $user_id, $key, $data);
	}
	update_user_meta( $user_id, 'payment_status', 'failure' );
	//session_destroy();

	$to = $email_id;
	$subject = "Verification Mail from Super Markeet";
	$txt = "Hello ".$email_id.". Thanks for showing interest in us. Due to some reason, payment got fail. Please try again.";
	$emailTxt = "Hello ".$email_id.". <br/><br/> Thanks for showing interest in us. <br/>Please try again as your payment got fail.";
	$user_meta_data=get_user_meta( $user_id );
	$phone_number=$user_meta_data['phone_number'][0];
	send_success_sms($phone_number, $txt);
	$message='<section class="full-page container" style="padding-top: 1rem; width: 100%; clear: both;">
		<div class="heading-one" style="padding: 18px 30px 98px 30px; background-color: #fdb143; color: #fff; font-size: 24px; clear: both;">
			<div style="width: 22%; float: left;"><a href="https://www.supermarkeet.com/" title="Super Markeet"><img style="width: 80%;" src="https://www.supermarkeet.com/wp-content/uploads/2020/08/cropped-supermarkeet.png" alt="Super Markeet Logo" /></a> </div>
			<h1 style="margin-top: 0px; float: left;  width: 70%;">Welcome to Super Markeet</h1>
		</div>
		<div class="sub-title" style="padding: 16px; border: 1px solid #ddd;">'.$emailTxt.'</div>
	</section>';
	$from = 'support@supermarkeet.com';
	$headers  = 'MIME-Version: 1.0' . "\r\n";
	$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
 	// Create email headers
	$headers .= 'From: '.$from."\r\n". 'Reply-To: '.$from."\r\n" . 'X-Mailer: PHP/' . phpversion();
	if(mail($to,$subject,$message,$headers)) {
		echo 'Your mail has been sent successfully.';
	} else {
		echo 'Unable to send email. Please try again.';
	}


	$success_msg="You have unsuccessfully pay for Shop manager Account. Please try again.";
	echo "<script>swal('Success','".$success_msg."','success')</script>";
	echo "<script>setTimeout(function(){ window.location.href='".home_url()."'; }, 5000)</script>";
}
if((null!==$_GET['email_id']) && (null!==$_GET['razorpay_payment_id'])){
	$email_id=base64_decode($_GET['email_id']);
	$razorpay_payment_id=base64_decode($_GET['razorpay_payment_id']);
	$user_data=get_user_by_email($email_id);
	$user_id=$user_data->data->ID;
	$user_activation_key=$user_data->data->user_activation_key;
	add_user_meta( $user_id, 'razorpay_payment_id', $razorpay_payment_id );
	update_user_meta( $user_id, 'payment_status', 'success' );
	//session_destroy();

	$to = $email_id;
	$subject = "Verification Mail from Super Markeet";
	$txt = "Hello ".$email_id.". Thanks for registering with us. Please check your email to activate your account!";
	$emailTxt = "Hello ".$email_id.". <br/><br/> Thanks for registering with us. <br/>Please click on below link for activate account!<br/><br/>".get_permalink()."?email_id=".$email_id."&activation_key=".$user_activation_key;
	$user_meta_data=get_user_meta( $user_id );
	$phone_number=$user_meta_data['phone_number'][0];
	send_success_sms($phone_number, $txt);
	$message='<section class="full-page container" style="padding-top: 1rem; width: 100%; clear: both;">
		<div class="heading-one" style="padding: 18px 30px 98px 30px; background-color: #fdb143; color: #fff; font-size: 24px; clear: both;">
			<div style="width: 22%; float: left;"><a href="https://www.supermarkeet.com/" title="Super Markeet"><img style="width: 80%;" src="https://www.supermarkeet.com/wp-content/uploads/2020/08/cropped-supermarkeet.png" alt="Super Markeet Logo" /></a> </div>
			<h1 style="margin-top: 0px; float: left;  width: 70%;">Welcome to Super Markeet</h1>
		</div>
		<div style="clear: both; margin-left: 2%; margin-bottom: 4%; font-size: 18px;">
			<span style="font-size: 30px;">Your Payment Invoice</span>
    		<table style="text-align: left; color: black; width: 60%;">
				<tr>
					<th style="font-weight: 100; width: 44%;">Registration Charges</th>
					<td style="width: 10%;"> : </td>
					<td style="font-weight: 600; width: 40%;"> 199 INR</td>
				</tr>
				<tr>
					<th style="font-weight: 100; width: 44%;">GST Charges:</th>
					<td style="width: 10%;"> : </td>
					<td style="font-weight: 600;  width: 40%;"> 35.82 INR</td>
				</tr>
				<tr>
					<td colspan="3" style="border-top: 1px solid black;"></td>
				</tr>
				<tr>
					<th style="font-weight: 100; width: 44%;">Total Cost:</th>
					<td style="width: 10%;"> : </td>
					<td style="font-weight: 600;  width: 40%;"> 234.82 INR  : (Round) - 235 INR</td>
				</tr>
			</table>
		</div>
		<div class="sub-title" style="padding: 16px; border: 1px solid #ddd;">'.$emailTxt.'</div>
	</section>';

	$from = 'support@supermarkeet.com';
	$headers  = 'MIME-Version: 1.0' . "\r\n";
	$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
 	// Create email headers
	$headers .= 'From: '.$from."\r\n". 'Reply-To: '.$from."\r\n" . 'X-Mailer: PHP/' . phpversion();
	if(mail($to,$subject,$message,$headers)) {
		echo 'Your mail has been sent successfully.';
	} else {
		echo 'Unable to send email. Please try again.';
	}
	$success_msg="You have successfully pay for Shop manager Account. Please verify the account using email!";
	echo "<script>swal('Success','".$success_msg."','success')</script>";
	echo "<script>setTimeout(function(){ window.location.href='".home_url()."'; }, 5000)</script>";
}
if(null!==$_GET['email_id'] && null!==$_GET['activation_key']){
	$email_id=$_GET['email_id'];
	$activation_key=$_GET['activation_key'];
	$get_user = $wpdb->get_results("SELECT * FROM ".$wpdb->prefix."users WHERE user_email='".$email_id."' AND user_activation_key='".$activation_key."'");
	if(count($get_user)>0){
		$user_data=get_user_by_email($email_id);
		$user_id=$user_data->data->ID;
		$wp_user_object = new WP_User($user_id);
		$wp_user_object->set_role('shop_manager');
		$wpdb->update(
			$wpdb->prefix."users",
			array("user_activation_key"=>""),
			array("ID"=>$get_user[0]->ID)
		);
		$to = $email_id;
		$subject = "Activation Mail";
		$user_meta_data=get_user_meta( $user_id );
		$password=$user_meta_data['password'][0];
		$txt = "Hello ".$get_user[0]->display_name.". <br/><br/> You account has activated successfully. Your username is ".$get_user[0]->user_login.". You can access your account area to view orders, change your password, and more.<br/><b>Username:<b/> ".$get_user[0]->user_login." <br/><b>Password:<b/> ".$password." <br/><br/><a href='".home_url()."/my-account'>Please click here for login</a>!";
		$phone_number=$user_meta_data['phone_number'][0];
		send_success_sms($phone_number, $txt);
		$message='<section class="full-page container" style="padding-top: 1rem; width: 100%; clear: both;">
			<div class="heading-one" style="padding: 18px 30px 98px 30px; background-color: #fdb143; color: #fff; font-size: 24px; clear: both;">
				<div style="width: 22%; float: left;">
					<a href="https://www.supermarkeet.com/" title="Super Markeet"><img style="width: 80%;" src="https://www.supermarkeet.com/wp-content/uploads/2020/08/cropped-supermarkeet.png" alt="Super Markeet Logo" /></a>
				</div>
				<h1 style="margin-top: 0px; float: left;  width: 70%;">Welcome to Super Markeet</h1>
			</div>
			<div class="sub-title" style="padding: 16px; border: 1px solid #ddd; padding-left: 30px;">'.$txt.'</div>
		</section>';
		// $headers = "From: info@kanvan.in";
		$from = 'support@supermarkeet.com';
		$headers  = 'MIME-Version: 1.0' . "\r\n";
		$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";

		// mail($to,$subject,$message,$headers);
		$headers .= 'From: '.$from."\r\n". 'Reply-To: '.$from."\r\n" . 'X-Mailer: PHP/' . phpversion();
		if(mail($to,$subject,$message,$headers)) {
			echo 'Your mail has been sent successfully.';
		} else {
			echo 'Unable to send email. Please try again.';
		}

		$to = "support@supermarkeet.com";
		$subject = "Activation Mail Update";
		$txt = "Hello Admin. <br/><br/>".$get_user[0]->display_name."(".$email_id.") has recently registered with supermarkeet as a vendor!";
		$user_meta_data=get_user_meta( $user_id );
		$phone_number=$user_meta_data['phone_number'][0];
		send_success_sms($phone_number, $txt);
		$message='<section class="full-page container" style="padding-top: 1rem; width: 100%; clear: both;">
			<div class="heading-one" style="padding: 18px 30px 98px 30px; background-color: #fdb143; color: #fff; font-size: 24px; clear: both;">
				<div style="width: 30%; float: left;"><a href="https://www.supermarkeet.com/" title="Super Markeet"><img style="width: 80%;" src="https://www.supermarkeet.com/wp-content/uploads/2020/08/cropped-supermarkeet.png" alt="Super Markeet Logo" /></a> </div>
				<h1 style="margin-top: 0px; float: left;  width: 70%;">Welcome to Super Markeet</h1>
			</div>
			<div class="sub-title" style="padding: 16px; border: 1px solid #ddd; padding-left: 30px;">'.$txt.'</div>
		</section>';


		$headers  = 'MIME-Version: 1.0' . "\r\n";
		$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
		// Create email headers
		$headers .= 'From: '.$email_id."\r\n". 'Reply-To: '.$email_id."\r\n" . 'X-Mailer: PHP/' . phpversion();
		if(mail($to,$subject,$message,$headers)) {
			echo 'Your mail has been sent successfully.';
		} else {
			echo 'Unable to send email. Please try again.';
		}

		$success_msg="User Activated successfully!";
		echo "<script>swal('Success','".$success_msg."','success')</script>";
		echo "<script>setTimeout(function(){ window.location.href='".home_url()."/login'; }, 5000)</script>";
	}
	else{
		$error_msg="Activation key is wrong!";
		echo "<script>swal('Error','".$error_msg."','error')</script>";
	}
}
function is_required($field_name){
	global $wpdb;
	$get_data=$wpdb->get_results("SELECT * FROM {$wpdb->prefix}multistep_option WHERE opt='required_field' and field='".$field_name."'");
	if(count($get_data)>0){
		return true;
	}
	else{
		return false;
	}
}
function send_success_sms($phone_number, $text_message){
	$handle = curl_init();
	$url = "https://api.textlocal.in/send/?apiKey=Jz0sPt9cSBc-5uSObptlg2rnrvqAHHiaYKNCBSjxll&sender=TXTLCL&numbers=91".$phone_number."&message=".urlencode(strip_tags($text_message));
	// Set the url
	curl_setopt($handle, CURLOPT_URL, $url);
	// Set the result output to be a string.
	curl_setopt($handle, CURLOPT_RETURNTRANSFER, true);
	$output = curl_exec($handle);
	curl_close($handle);
}
$user_data=$_SESSION['user_data'];
?>

<style>
/* Style the form */
#regForm {
  background-color: #ffffff;
  margin: 100px auto;
  padding: 40px;
  width: 70%;
  min-width: 300px;
}

/* Style the input fields */
input {
  padding: 10px;
  width: 100%;
  font-size: 17px;
  font-family: Raleway;
  border: 1px solid #aaaaaa;
}

/* Mark input boxes that gets an error on validation: */
input.invalid {
  background-color: #ffdddd;
}

/* Hide all steps by default: */
.tab {
  display: none;
}

/* Make circles that indicate the steps of the form: */
.step {
  height: 15px;
  width: 15px;
  margin: 0 2px;
  background-color: #bbbbbb;
  border: none;
  border-radius: 50%;
  display: inline-block;
  opacity: 0.5;
}
label {
    float: left!important;
}

/* Mark the active step: */
.step.active {
  opacity: 1;
}

/* Mark the steps that are finished and valid: */
.step.finish {
  background-color: #4CAF50;
}

element.style {
}
select#inlineFormCustomSelect {
    width: 300px!important;
}

</style>

<form id="regForm" action="">

<h1>Event Registration form</h1>

<!-- One "tab" for each step in the form: -->
<br><br>
<div class="tab"><h3>Personal information</h3>
<br>
<br>
<label><span>Name</span></label>
  <p><input type="text" placeholder="name..." name="fullname" class="form-control" value="" oninput="this.className = ''"></p>
  <label><span>Date</span></label>
  <p><input type="date"  placeholder="Date..."  name="date" class="form-control" value="" oninput="this.className = ''"></p>
  <label><span>mobile Number</span></label>
  <p><input type="tel"  placeholder="Phone number..." name="phone" class="form-control" value=""  oninput="this.className = ''"></p>
  <label><span>Email</span></label>
  <p><input type="email"  placeholder="Email..." name="email" class="form-control" value="" oninput="this.className = ''"></p>
  <label><span>Date of Birth</span></label>
  <p><input type="date"  placeholder="Date of Birth..." name="dob" value=""  class="form-control" oninput="this.className = ''"></p>
  <label><span>Age</span></label>
 <p><input type="number"  placeholder="Age..." value="" name="age" class="form-control" oninput="this.className = ''"></p>
 <label><span>Height</span></label>
  <p><input type="number"  placeholder="Height..." name="height" value="" class="form-control"  oninput="this.className = ''"></p>
  <label><span>Weight</span></label>
  <p><input type="number"  placeholder="Weight..." name="weight" value=""  oninput="this.className = ''"></p>
  <label><span>In Case of Emergency Contact </span></label>
  <p><input type="number"  placeholder="Emergency Contact..."  name="weight" value="" oninput="this.className = ''"></p>
  <label><span>Relationship</span></label>
  <p><input type="text"  placeholder="Relationship..." value=""  oninput="this.className = ''"></p>
  <label><span>Address</span></label>
  <p><input type="text"  placeholder="Address..." name="address" value=""  oninput="this.className = ''"></p>
</div>

<div class="tab">Medical Information:
<br>
<br>
	<label><span>Are you currently under a doctor’s care:</span></label>
  <p> <select class="custom-select mr-sm-2" id="inlineFormCustomSelect" oninput="this.className = ''">
        <option selected>Choose...</option>
        <option value="1">yes</option>
        <option value="2">NO</option>
      </select></p>
	  <label><span>If yes, explain:</span></label>
  <p><input type="text" placeholder="name..." class="form-control" oninput="this.className = ''"></p>
  <label><span>When was the last time you had a physical examination? </span></label>
  <p><input type="text" placeholder="name..." class="form-control" oninput="this.className = ''"></p>
	  <label><span>Have you ever had an exercise stress test:</span></label>
	  <p> <select class="custom-select mr-sm-2" id="inlineFormCustomSelect" oninput="this.className = ''">
        <option selected>Choose...</option>
        <option value="1">yes</option>
        <option value="2">NO</option>
        <option value="3">Don’t Know</option>
      </select></p>
	  <label><span>If yes, were the results:</span></label>
  <p> <select class="custom-select mr-sm-2" id="inlineFormCustomSelect" oninput="this.className = ''">
        <option selected>Choose...</option>
        <option value="1">Normal</option>
        <option value="2">Abnormal</option>
      </select></p>
	  <label><span>Do you take any medications on a regular basis?</span></label>
	  <p> <select class="custom-select mr-sm-2" id="inlineFormCustomSelect" oninput="this.className = ''">
        <option selected>Choose...</option>
        <option value="1">yes</option>
        <option value="2">NO</option>
      </select></p>
	  <label><span>If yes, please list medications and reasons for taking:</span></label>
  <p><input type="text" placeholder="name..." class="form-control" oninput="this.className = ''"></p>
	  <label><span>Have you been recently hospitalized?</span></label>
  <p> <select class="custom-select mr-sm-2" id="inlineFormCustomSelect" oninput="this.className = ''">
        <option selected>Choose...</option>
        <option value="1">yes</option>
        <option value="2">NO</option>
      </select></p>
	  <label><span>Address</span></label>
	  <p> <select class="custom-select mr-sm-2" id="inlineFormCustomSelect" oninput="this.className = ''">
        <option selected>Choose...</option>
        <option value="1">yes</option>
        <option value="2">NO</option>
        <option value="3">Three</option>
      </select></p>
	  <label><span>If yes, explain:</span></label>
  <p><input type="text" placeholder="name..." class="form-control" oninput="this.className = ''"></p>
	  <label><span>Do you smoke?</span></label>
  <p> <select class="custom-select mr-sm-2" id="inlineFormCustomSelect" oninput="this.className = ''">
        <option selected>Choose...</option>
        <option value="1">yes</option>
        <option value="2">NO</option>
      </select></p>
	  <label><span>Are you pregnant?</span></label>
	  <p> <select class="custom-select mr-sm-2" id="inlineFormCustomSelect" oninput="this.className = ''">
        <option selected>Choose...</option>
        <option value="1">yes</option>
        <option value="2">NO</option>
      </select></p>
	  <label><span>Do you drink alcohol more than three times/week?</span></label>
  <p> <select class="custom-select mr-sm-2" id="inlineFormCustomSelect" oninput="this.className = ''">
        <option selected>Choose...</option>
        <option value="1">yes</option>
        <option value="2">NO</option>
      </select></p>
	  <label><span>Is your stress level high?</span></label>
	  <p> <select class="custom-select mr-sm-2" id="inlineFormCustomSelect" oninput="this.className = ''">
        <option selected>Choose...</option>
        <option value="1">yes</option>
        <option value="2">NO</option>
      </select></p>
	  <label><span>Are you moderately active on most days of the week?</span></label>
  <p> <select class="custom-select mr-sm-2" id="inlineFormCustomSelect" oninput="this.className = ''">
        <option selected>Choose...</option>
        <option value="1">yes</option>
        <option value="2">NO</option>
      </select></p>
	  Do you have:
	  <br>
	  <br>
	  <label><span>High blood pressure?</span></label>
	  <p> <select class="custom-select mr-sm-2" id="inlineFormCustomSelect" oninput="this.className = ''">
        <option selected>Choose...</option>
        <option value="1">yes</option>
        <option value="2">NO</option>
      </select></p>
	  <label><span>High cholesterol?</span></label>
  <p> <select class="custom-select mr-sm-2" id="inlineFormCustomSelect" oninput="this.className = ''">
        <option selected>Choose...</option>
        <option value="1">yes</option>
        <option value="2">NO</option>
      </select></p>
	  <label><span>Diabetes?</span></label>
	  <p> <select class="custom-select mr-sm-2" id="inlineFormCustomSelect" oninput="this.className = ''">
        <option selected>Choose...</option>
        <option value="1">yes</option>
        <option value="2">NO</option>
      </select></p>
	  <label><span>Have parents or siblings who, prior to age 55 had:</span></label>
  <p> <select class="custom-select mr-sm-2" id="inlineFormCustomSelect" oninput="this.className = ''">
        <option selected>Choose...</option>
        <option value="1">yes</option>
        <option value="2">NO</option>
      </select></p>
	  <label><span>A heart attack?</span></label>
	  <p> <select class="custom-select mr-sm-2" id="inlineFormCustomSelect" oninput="this.className = ''">
        <option selected>Choose...</option>
        <option value="1">yes</option>
        <option value="2">NO</option>
      </select></p>
	  <label><span>A stroke?</span></label>
  <p> <select class="custom-select mr-sm-2" id="inlineFormCustomSelect" oninput="this.className = ''">
        <option selected>Choose...</option>
        <option value="1">yes</option>
        <option value="2">NO</option>
      </select></p>
	  <label><span>High blood pressure?</span></label>
	  <p> <select class="custom-select mr-sm-2" id="inlineFormCustomSelect" oninput="this.className = ''">
        <option selected>Choose...</option>
        <option value="1">yes</option>
        <option value="2">NO</option>
      </select></p>
	  <label><span>High cholesterol?</span></label>
  <p> <select class="custom-select mr-sm-2" id="inlineFormCustomSelect" oninput="this.className = ''">
        <option selected>Choose...</option>
        <option value="1">yes</option>
        <option value="2">NO</option>
      </select></p>
	  <label><span>Known heart disease?</span></label>
	  <p> <select class="custom-select mr-sm-2" id="inlineFormCustomSelect" oninput="this.className = ''">
        <option selected>Choose...</option>
        <option value="1">yes</option>
        <option value="2">NO</option>
      </select></p>
	  <label><span>Rheumatic heart disease?</span></label>
  <p> <select class="custom-select mr-sm-2" id="inlineFormCustomSelect" oninput="this.className = ''">
        <option selected>Choose...</option>
        <option value="1">yes</option>
        <option value="2">NO</option>
      </select></p>
	  <label><span>A heart murmur?</span></label>
	  <p> <select class="custom-select mr-sm-2" id="inlineFormCustomSelect" oninput="this.className = ''">
        <option selected>Choose...</option>
        <option value="1">yes</option>
        <option value="2">NO</option>
      </select></p>
	  <label><span>Chest pain with exertion?</span></label>
  <p> <select class="custom-select mr-sm-2" id="inlineFormCustomSelect" oninput="this.className = ''">
        <option selected>Choose...</option>
        <option value="1">yes</option>
        <option value="2">NO</option>
      </select></p>
	  <label><span>Irregular heart beat or palpitations?</span></label>
	  <p> <select class="custom-select mr-sm-2" id="inlineFormCustomSelect" oninput="this.className = ''">
        <option selected>Choose...</option>
        <option value="1">yes</option>
        <option value="2">NO</option>
      </select></p>
	  <label><span>Lightheadedness or do you faint?</span></label>
  <p> <select class="custom-select mr-sm-2" id="inlineFormCustomSelect" oninput="this.className = ''">
        <option selected>Choose...</option>
        <option value="1">yes</option>
        <option value="2">NO</option>
      </select></p>
	  <label><span>Unusual shortness of breath?</span></label>
	  <p> <select class="custom-select mr-sm-2" id="inlineFormCustomSelect" oninput="this.className = ''">
        <option selected>Choose...</option>
        <option value="1">yes</option>
        <option value="2">NO</option>
      </select></p>
	  <label><span>Cramping pains in legs or feet?</span></label>
  <p> <select class="custom-select mr-sm-2" id="inlineFormCustomSelect" oninput="this.className = ''">
        <option selected>Choose...</option>
        <option value="1">yes</option>
        <option value="2">NO</option>
      </select></p>
	  <label><span>Emphysema?</span></label>
	  <p> <select class="custom-select mr-sm-2" id="inlineFormCustomSelect" oninput="this.className = ''">
        <option selected>Choose...</option>
        <option value="1">yes</option>
        <option value="2">NO</option>
      </select></p>
	  <label><span>Other metabolic disorders (thyroid, kidney, etc.)?</span></label>
	  <p> <select class="custom-select mr-sm-2" id="inlineFormCustomSelect" oninput="this.className = ''">
        <option selected>Choose...</option>
        <option value="1">yes</option>
        <option value="2">NO</option>
      </select></p>
	  <label><span>Epilepsy?</span></label>
	  <p> <select class="custom-select mr-sm-2" id="inlineFormCustomSelect" oninput="this.className = ''">
        <option selected>Choose...</option>
        <option value="1">yes</option>
        <option value="2">NO</option>
      </select></p>
	  <label><span>Asthma?</span></label>
	  <p> <select class="custom-select mr-sm-2" id="inlineFormCustomSelect" oninput="this.className = ''">
        <option selected>Choose...</option>
        <option value="1">yes</option>
        <option value="2">NO</option>
      </select></p>
	  <label><span>Back pain: upper, middle, lower?</span></label>
	  <p> <select class="custom-select mr-sm-2" id="inlineFormCustomSelect" oninput="this.className = ''">
        <option selected>Choose...</option>
        <option value="1">yes</option>
        <option value="2">NO</option>
      </select></p>
	  <label><span>Other joint pain (explain on back of form)?</span></label>
	  <p> <select class="custom-select mr-sm-2" id="inlineFormCustomSelect" oninput="this.className = ''">
        <option selected>Choose...</option>
        <option value="1">yes</option>
        <option value="2">NO</option>
      </select></p>
	  <label><span>Muscle pain or an injury (explain on back of Form)?</span></label>
	  <p> <select class="custom-select mr-sm-2" id="inlineFormCustomSelect" oninput="this.className = ''">
        <option selected>Choose...</option>
        <option value="1">yes</option>
        <option value="2">NO</option>
      </select></p>
	  <br>
	  To the best of my knowledge, the above information is true.
	  <br>
	  <label><span>Sign Name (Type your name):</span></label>
  <p><input type="text" placeholder="Sign Name..." class="form-control" oninput="this.className = ''"></p>
  <label><span>Date</span></label>
  <p><input type="text" placeholder="Date..." class="form-control" oninput="this.className = ''"></p>
</div>

<!-- <div class="tab">:
  
</div> -->

<div class="tab">Login Info:
  <p><input placeholder="Username..." oninput="this.className = ''"></p>
  <p><input placeholder="Password..." oninput="this.className = ''"></p>
</div>

<div style="overflow:auto;">
  <div style="float:right;">
    <button type="button" id="prevBtn" onclick="nextPrev(-1)">Previous</button>
    <button type="button" id="nextBtn" onclick="nextPrev(1)">Next</button>
  </div>
</div>

<!-- Circles which indicates the steps of the form: -->
<div style="text-align:center;margin-top:40px;">
  <span class="step"></span>
  <span class="step"></span>
  <span class="step"></span>
  <span class="step"></span>
</div>

</form>


<script>

var currentTab = 0; // Current tab is set to be the first tab (0)
showTab(currentTab); // Display the current tab

function showTab(n) {
  // This function will display the specified tab of the form ...
  var x = document.getElementsByClassName("tab");
  x[n].style.display = "block";
  // ... and fix the Previous/Next buttons:
  if (n == 0) {
    document.getElementById("prevBtn").style.display = "none";
  } else {
    document.getElementById("prevBtn").style.display = "inline";
  }
  if (n == (x.length - 1)) {
    document.getElementById("nextBtn").innerHTML = "Submit";
  } else {
    document.getElementById("nextBtn").innerHTML = "Next";
  }
  // ... and run a function that displays the correct step indicator:
  fixStepIndicator(n)
}

function nextPrev(n) {
  // This function will figure out which tab to display
  var x = document.getElementsByClassName("tab");
  // Exit the function if any field in the current tab is invalid:
  if (n == 1 && !validateForm()) return false;
  // Hide the current tab:
  x[currentTab].style.display = "none";
  // Increase or decrease the current tab by 1:
  currentTab = currentTab + n;
  // if you have reached the end of the form... :
  if (currentTab >= x.length) {
    //...the form gets submitted:
    document.getElementById("regForm").submit();
    return false;
  }
  // Otherwise, display the correct tab:
  showTab(currentTab);
}

function validateForm() {
  // This function deals with validation of the form fields
  var x, y, i, valid = true;
  x = document.getElementsByClassName("tab");
  y = x[currentTab].getElementsByTagName("input");
  // A loop that checks every input field in the current tab:
  for (i = 0; i < y.length; i++) {
    // If a field is empty...
    if (y[i].value == "") {
      // add an "invalid" class to the field:
      y[i].className += " invalid";
      // and set the current valid status to false:
      valid = false;
    }
  }
  // If the valid status is true, mark the step as finished and valid:
  if (valid) {
    document.getElementsByClassName("step")[currentTab].className += " finish";
  }
  return valid; // return the valid status
}

function fixStepIndicator(n) {
  // This function removes the "active" class of all steps...
  var i, x = document.getElementsByClassName("step");
  for (i = 0; i < x.length; i++) {
    x[i].className = x[i].className.replace(" active", "");
  }
  //... and adds the "active" class to the current step:
  x[n].className += " active";
}

</script>
<?php
$name = $_POST["fullname"];
$date = $_POST["date"];
$dob = $_POST["dob"];
$age = $_POST["age"];
$phone = $_POST["phone"];
$email = $_POST["email"];

?>
<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "kanvansports";

$conn = mysqli_connect($servername, $username, $password, $dbname);
if (!$conn) {
	die("Connection failed: " . mysqli_connect_error());
}else{
	$sql = "INSERT INTO sports(name,date,email,phone,dob,age)
	VALUES ('$name','$date', '$email','$phone','$dob','$age',)";
}
if ($conn->query($sql) === TRUE) {
	exit;
  } else {
	echo "Error: " . $sql . "<br>" . $conn->error;
  }

mysqli_close($conn);
?>

<script>
$(document).ready(function(){
	var current_fs, next_fs, previous_fs; //fieldsets
	var opacity;
	var current = 1;
	var steps = $("fieldset").length;
	setProgressBar(current);
	jQuery(".next").click(function(){
		if(jQuery('[name="email_address"]').val()==""){
			jQuery(".enter_email_err").html("Please enter email address!").show();
		}
		else if( !validateEmail(jQuery('[name="email_address"]').val())) {
			jQuery(".enter_email_err").html("Please enter correct email address!").show();
		}
		else if(jQuery('[name="email_verify"]').val()==0){
			jQuery(".enter_email_err").html("Email already exist!").show();
		}
		else if(jQuery("#enter_otp_phone").length==0){
			jQuery(".enter_email_err").hide();
			var valid=true;
			jQuery(this).parent().find(".required").each(function(){
				if(jQuery(this).val()==""){
					jQuery(this).addClass("invalid");
					valid=false;
				}
			});
			if(valid==true){
				current_fs = jQuery(this).parent();
				next_fs = jQuery(this).parent().next();
				//Add Class Active
				jQuery("#progressbar li").eq($("fieldset").index(next_fs)).addClass("active");
				//show the next fieldset
				next_fs.show();
				//hide the current fieldset with style
				current_fs.animate({opacity: 0}, {
					step: function(now) {
						// for making fielset appear animation
						opacity = 1 - now;
						current_fs.css({
						'display': 'none',
						'position': 'relative'
						});
						next_fs.css({'opacity': opacity});
					},
					duration: 500
				});
				setProgressBar(++current);
			}
		}
		else{
			jQuery(".enter_email_err").hide();
			jQuery(".enter_phone_err").html("Phone has not verified yet!");
			jQuery("#enter_phone").addClass("invalid");
		}
	});
	$(".previous").click(function(){
		current_fs = jQuery(this).parent();
		previous_fs = jQuery(this).parent().prev();
		//Remove class active
		jQuery("#progressbar li").eq($("fieldset").index(current_fs)).removeClass("active");
		//show the previous fieldset
		previous_fs.show();
		//hide the current fieldset with style
		current_fs.animate({opacity: 0}, {
			step: function(now) {
				// for making fielset appear animation
				opacity = 1 - now;
				current_fs.css({
					'display': 'none',
					'position': 'relative'
				});
				previous_fs.css({'opacity': opacity});
			},
			duration: 500
		});
		setProgressBar(--current);
	});
	function setProgressBar(curStep){
		var percent = parseFloat(100 / steps) * curStep;
		percent = percent.toFixed();
		jQuery(".progress-bar")
		.css("width",percent+"%")
	}
	jQuery(".submit").click(function(){
		return false;
	});
});
function validateEmail($email) {
	var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
	return emailReg.test( $email );
}
function checkEmail(email_id){
	if(email_id!=""){
		jQuery(".enter_email_err").hide();
		jQuery.ajax({
			type: "post",
			url: "<?php echo home_url(); ?>/wp-admin/admin-ajax.php",
			data: {
				action:'check_email',
				email_id: email_id,
			}
		})
		.done(function( result ) {
			if(result=='verify'){
				jQuery("[name='email_verify']").val(1);
			}
			else{
				jQuery("[name='email_verify']").val(0);
			}
		});
	}
}
</script>

<script>
jQuery(document).ready(function(){
	jQuery(".send_otp_phone").click(function(){
		var phone_number=jQuery('[name="phone_number"]').val();
		if(phone_number==""){
			jQuery('.enter_phone_err').html('Please enter phone number!').show();
			jQuery('.enter_otp_phone').hide();
		}
		else if(jQuery('[name="phone_number"]').val().length!=10){
			jQuery('.enter_phone_err').html('Please enter correct phone number!').show();
			jQuery('.enter_otp_phone').hide();
		}
		else{
			jQuery.ajax({
				type: "post",
				//dataType: "json",
				url: "<?php echo home_url(); ?>/wp-admin/admin-ajax.php",
				data: {
					action:'phone_number',
					phone_number: phone_number,
				}
			})
			.done(function( msg ) {
				if(msg != "exist"){
					jQuery('.enter_phone_err').hide();
					jQuery('.enter_otp_phone').show();
				}
				else{
					jQuery('.enter_phone_err').html('Phone already exist!').show();
					jQuery('.enter_otp_phone').hide();
				}
			});
		}
	});
	jQuery(".otp_phone_verify").click(function(){
		jQuery.ajax({
			type: "post",
			//dataType: "json",
			url: "<?php echo home_url(); ?>/wp-admin/admin-ajax.php",
			data: {
				action:'phone_number_verify',
				phone_number: jQuery('[name="phone_number"]').val(),
				enter_otp_phone: jQuery('#enter_otp_phone').val(),
			}
		})
		.done(function( msg ) {
			if(msg=='verify'){
				jQuery('.enter_otp_phone').html('<i class="fa fa-check-circle" aria-hidden="true"></i>Phone has been verified!');
				jQuery("#enter_phone").removeClass("invalid").attr('readonly', true);
			}
			else{
				jQuery(".enter_otp_phone_err").html("Please enter correct OTP!");
			}
		});
	});
});
</script>
<script>
jQuery(document).ready(function(){
	jQuery('[name="email_address"]').keyup(function(){
		jQuery(".enter_email_err").hide();
		var email_id=jQuery(this).val();
		jQuery.ajax({
			type: "post",
			url: "<?php echo home_url(); ?>/wp-admin/admin-ajax.php",
			data: {
				action:'check_email',
				email_id: email_id,
			}
		})
		.done(function( result ) {
			if(result=='verify'){
				jQuery("[name='email_verify']").val(1);
			}
			else{
				jQuery("[name='email_verify']").val(0);
			}
		});
	});
	jQuery('[name="country"]').change(function(){
		jQuery("#cover-spin").show();
		var country_id=jQuery(this).val();
		jQuery.ajax({
			type: "post",
			url: "<?php echo home_url(); ?>/wp-admin/admin-ajax.php",
			data: {
				action:'get_states',
				country_id: country_id,
			}
		})
		.done(function( result ) {
			jQuery('[name="state"] option').remove();
			jQuery('[name="state"]').append(new Option("--Select--", ""));
			jQuery.each(JSON.parse(result), function(i, field){
				jQuery('[name="state"]').append(new Option(field.name, field.id));
			});
			jQuery("#cover-spin").hide();
		});
	});
	jQuery('[name="state"]').change(function(){
		jQuery("#cover-spin").show();
		var state_id=jQuery(this).val();
		jQuery.ajax({
			type: "post",
			url: "<?php echo home_url(); ?>/wp-admin/admin-ajax.php",
			data: {
				action:'get_cities',
				state_id: state_id,
			}
		})
		.done(function( result ) {
			jQuery('[name="city"] option').remove();
			jQuery('[name="city"]').append(new Option("--Select--", ""));
			jQuery.each(JSON.parse(result), function(i, field){
				jQuery('[name="city"]').append(new Option(field.name, field.id));
			});
			jQuery("#cover-spin").hide();
		});
	});
	jQuery("#regForm").submit(function(){
		jQuery("#cover-spin").show();
		var formData = new FormData($(this)[0]);
		$.ajax({
			url: "<?php echo home_url(); ?>/wp-admin/admin-ajax.php",
			type: 'POST',
			data: formData,
			async: false,
			success: function (data) {
				data=JSON.parse(data);
				console.log('data', data);
				if(data.action=="razorpay"){
					window.location.href=data.redirect_url;
				}
				if(data.action=="cashfree"){
					jQuery(".cashfree_form").html(data.form_data);
					jQuery("#cashfreeForm").submit();
				}
				else{
					//window.location.href="?alert=something_wrong";
				}
			},
			cache: false,
			contentType: false,
			processData: false
		});
		return false;
	});
})
</script>

