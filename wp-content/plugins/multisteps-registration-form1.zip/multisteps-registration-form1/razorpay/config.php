<?php

// $keyId = 'rzp_test_uHrQgVXwF2S0F8';
// $keySecret = 'GHg3opjTU7UBDrfbJJ9IkrZF';

$keyId = 'rzp_live_RBOZKehn5kFBO0';
$keySecret = 'W3wH8yNJMsddWdevtfCnhPja';
$displayCurrency = 'INR';

//These should be commented out in production
// This is for error reporting
// Add it to config.php to report any errors
error_reporting(E_ALL);
ini_set('display_errors', 1);
